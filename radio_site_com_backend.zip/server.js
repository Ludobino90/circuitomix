
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const dataDir = path.join(__dirname, 'api');

function readJSON(file) {
  return JSON.parse(fs.readFileSync(path.join(dataDir, file), 'utf8'));
}

function writeJSON(file, data) {
  fs.writeFileSync(path.join(dataDir, file), JSON.stringify(data, null, 2));
}

app.get('/api/noticias', (req, res) => {
  res.json(readJSON('noticias.json'));
});

app.post('/api/noticias', (req, res) => {
  const noticias = readJSON('noticias.json');
  noticias.push(req.body);
  writeJSON('noticias.json', noticias);
  res.json({ success: true });
});

app.get('/api/eventos', (req, res) => {
  res.json(readJSON('eventos.json'));
});

app.post('/api/eventos', (req, res) => {
  const eventos = readJSON('eventos.json');
  eventos.push(req.body);
  writeJSON('eventos.json', eventos);
  res.json({ success: true });
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
